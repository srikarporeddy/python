package helpers

import "fmt"

func Help(data string) {
	fmt.Println("Hello helper, data is ", data, " !!")
}
