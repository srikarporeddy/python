package utils

import "fmt"

func Uti(data string) {
	fmt.Println(len(data))
}
