package main

import (
	"fmt"

	"github.com/GoesToEleven/GolangTraining/02_package/stringutil"
	"github.com/NirmalVatsyayan/GoPractice/15_packages/helpers"
	"github.com/NirmalVatsyayan/GoPractice/15_packages/utils"
)

func main() {
	fmt.Println(stringutil.Reverse("!oG ,olleH"))
	helpers.Help("nirmal")
	utils.Uti("nirmal")
}
