package main

import "fmt"

func main() {
	fmt.Println(string([]byte{'h', 'e', 'l', 'l', 'o'}))
	// conversion: []bytes to string
	// we'll learn about []bytes soon
}
