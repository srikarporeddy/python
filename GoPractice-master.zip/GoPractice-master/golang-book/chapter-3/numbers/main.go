package main

import (
	"fmt"
)

/*
Arithmetic operators:
+, - , *, / , %
*/

func main() {
	fmt.Println("Sum of 1+1 = ", 1+1)
	fmt.Println("Sum of 1.0 + 1.0 = ", 1.0+1.0)
}
