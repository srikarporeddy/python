package main

import "fmt"

func main() {
	fmt.Println("Enter a number :")
	var input int
	fmt.Scanf("%d", &input)
	fmt.Println("You entered ", input)
}
