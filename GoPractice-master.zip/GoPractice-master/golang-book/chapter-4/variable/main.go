package main

import "fmt"

func main() {
	var x string = "My name is Nirmal :)"
	fmt.Println(x)

	y := "My full name is Nirmal Vatsyayan :)"
	fmt.Println(y)

	var z string
	z = "My surname is Vatsyayan :)"
	fmt.Println(z)

}
