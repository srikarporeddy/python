package main

import "fmt"

/*
All code in golang-book is
created while reading book
of celeb doxey

*/

//this is a single line comment
func main() {
	/*
			  this is a
		    multiline comment
	*/
	fmt.Println("Hello world!!")
}
