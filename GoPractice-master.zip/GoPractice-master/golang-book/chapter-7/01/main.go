package main

import "fmt"

func average(x []float64) float64 {
	panic("Not implemented")
}

func main() {
	fmt.Println("Inside main function")
	x := average([]float64{1, 2, 3, 4})
	fmt.Println(x)
}
