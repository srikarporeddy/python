package main

import "fmt"

func main() {
	a := 10
	b := 20
	fmt.Println("Sum is ", a+b)
	fmt.Println("Substraction is ", a-b)
	fmt.Println("Multiplication is ", a*b)
	fmt.Println("Divison is ", a/b)
	fmt.Println("Remainder is ", a%b)

	fmt.Println("boolean ", false && true)
}
