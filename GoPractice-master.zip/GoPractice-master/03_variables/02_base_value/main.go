package main

import "fmt"

func main() {
	var iteration int
	var language string
	var marks float32
	var is_ok bool

	fmt.Println(iteration)
	fmt.Println(language)
	fmt.Println(marks)
	fmt.Println(is_ok)
}
