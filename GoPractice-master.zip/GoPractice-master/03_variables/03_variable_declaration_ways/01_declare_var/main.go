package main

import "fmt"

func main() {
	var message string
	message = "Hello World."
	fmt.Println(message)
}
