package main

import "fmt"

func greeting() {
	fmt.Println("Hello world!")
}

func main() {
	greeting()
}
